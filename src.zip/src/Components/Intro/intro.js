import React from 'react';
import './intro.css';
import { Link } from 'react-scroll';
import profile from '../../assests/profile (2).png';
import hire from '../../assests/hire.jpg';


const Intro = (props) => {
  return (
      <section id="intro">
<div className='introcontent'>
    <span className='hello'>Hello,</span>
    <span className='introtext'>I'm {" "}
    <span className='introname'>Shivani Jaiswal</span>
    <br/>Frontened Developer
    <p className='intropara'>I am Innovative front-end developer weaving digital experiences with front-end tools.<br></br>
     Passionate about creating visually stunning, user-centric websites that
      leave a lasting impact.<br/>
      and also Passionate in machine learning enthusiast skilled in algorithms, data analysis,<br/> and model development.
       Committed to leveraging AI for innovative solutions and insights.</p></span>
    <Link activeClass='active' to='cont' spy ={true} smooth ={true} offset ={-100} duration={500} className="desktoplistitem"><button className='btn'><img src={hire} alt ="" className="btnimg"/>Hire me</button></Link>
</div>
    <img src={profile} alt="profile" className='bg'/> 
    </section>
  );
}
export default Intro;
