import React, { useState } from 'react';
import './navbar.css';
import {Link} from 'react-scroll';
import logo from '../../assests/logo.jpg';




const Navbar = (props) => {
  const [showMenu , setShowMenu] = useState(false);
  return (
        <nav className ="navbar">
            <img src={logo} alt="logo" className="image"/>
            <div className ="desktopMenu">
              <Link activeClass='active' to='intro' spy ={true} smooth ={true} offset ={-100} duration={500}className="desktoplistitem">About </Link>
              <Link activeClass='active' to='skill' spy ={true} smooth ={true} offset ={-100} duration={500} className="desktoplistitem" >Works</Link>
              <Link activeClass='active' to='works' spy ={true} smooth ={true} offset ={-50}  duration={500}className="desktoplistitem" >Skills</Link>
              <Link activeClass='active' to='contact' spy ={true} smooth ={true} offset ={-50}duration={500}  className="desktoplistitem">Project</Link>
              <Link activeClass='active' to='Certification' spy ={true} smooth ={true} offset ={-100} duration={500} className="desktoplistitem">Achievement</Link>
              
            </div>
            <button className="desktopbtn" onClick={() => {
              document.getElementById('cont').scrollIntoView({behavior :'smooth'});
            }}>
                </button>
                <img src="" alt="Menu" className="mobmenu" onClick={()=>setShowMenu(!showMenu)}/>
            <div className ="navMenu" style={{display:showMenu?'flex':'none'}}>
              <Link activeClass='active' to='intro' spy ={true} smooth ={true} offset ={-100} duration={500}className="listitem" onClick={()=>setShowMenu(false)}>About </Link>
              <Link activeClass='active' to='skill' spy ={true} smooth ={true} offset ={-100} duration={500} className="listitem" onClick={()=>setShowMenu(false)} >Works</Link>
              <Link activeClass='active' to='works' spy ={true} smooth ={true} offset ={-50}  duration={500}className="listitem" onClick={()=>setShowMenu(false)}>Skills</Link>
              <Link activeClass='active' to='contact' spy ={true} smooth ={true} offset ={-50}duration={500}  className="listitem" onClick={()=>setShowMenu(false)}>Project</Link>
              <Link activeClass='active' to='Certification' spy ={true} smooth ={true} offset ={-100} duration={500} className="listitem" onClick={()=>setShowMenu(false)}>Achievement</Link>
              <Link activeClass='active' to='cont' spy ={true} smooth ={true} offset ={-100} duration={500} className="istitem" onClick={()=>setShowMenu(false)}>Contact Me</Link>
            </div> 

        </nav>
  );
}
export default Navbar;
