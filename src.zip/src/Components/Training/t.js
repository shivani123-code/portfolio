import React, { useRef } from 'react';
import './t.css';
import Linkedin from '../../assests/Linkedin.jpg';
import Github from '../../assests/Github.jpg';
import Kaggle from '../../assests/kaggle.png';
import cis from '../../assests/cisco.png';
import am from '../../assests/micro.jpg';
import u from  '../../assests/udemy.jpg';
import a from '../../assests/aws.png';
import gfg from '../../assests/hacker.png';
import g from '../../assests/gfg.png';
import c from '../../assests/cn.jpg';
import emailjs from '@emailjs/browser';



const Training = () => {
    const form = useRef();
    const sendEmail = (e) => {
        e.preventDefault();
    
        emailjs.sendForm('service_57yyaoo', 
        'template_c5ju47j', 
        form.current, 
        'Rc0TtgYgxXpUFskN2')
          .then((result) => {
              console.log(result.text);
              alert("Message sent!");
          }, (error) => {
              console.log(error.text);
          });
      };
    
  return (
    <section id="Certification">
    <h2 className='worktitle'>
        Certifications 
    </h2>
    <span className='workdesc'>Technicial Skills, I have </span>
    <div className="container">
        <main className="main_container">
            <div className="card_container">
                <a href="Link" className="card_image_container">
                    <img
                        src={Kaggle}
                        alt="Kaggle"
                        className="card_image"
                        loading="lazy"
                    />
                </a>

                <div className="card_title_container">
                    <a href="#" className="card_title_anchor">
                        <h2 className="card_title">Kaggle Expert</h2>
                    </a>
                    <p className="card_desc">
                        Have a look over my Kaggle Profile in which i have make a predicton over different datasets
                         using Machine Learning algorithm.
                    </p>
                </div>

                <div className="card_footer_container">

                    <div className="author_container">
                        <div className="author_avatar_container">
                            <img 
                                src="https://api.dicebear.com/7.x/notionists/svg?seed=John?size=64"
                                loading="lazy"
                                className="author_avatar"
                                alt="avatar 1"
                            />
                        </div>
                        <div className="author_info_container">
                            <span clasName="author_name">
                                
                            </span>
                            <span className="author_date">
                                 2021
                            </span>
                        </div>
                    </div>

                    <div >
                        <span className="card_tag_container">Machine Learning</span>
                    </div>
                </div>
            </div>
          

            <div className="card_container">
                <a href="#" className="card_image_container">
                    <img
                        src={cis}
                        alt="card 1 image"
                        className="card_image"
                        loading="lazy"
                    />
                </a>

                <div className="card_title_container">
                    <a href="#" className="card_title_anchor">
                        <h2 className="card_title">Data Essentials Badge</h2>
                    </a>
                    <p className="card_desc">
                        I am learn about Data Analyst , Data Visulaziation skills, and more about Big Data and SQL. 
                    </p>
                </div>

                <div className="card_footer_container">

                    <div className="author_container">
                        <div className="author_avatar_container">
                            <img 
                                src="https://api.dicebear.com/7.x/notionists/svg?seed=John?size=64"
                                loading="lazy"
                                className="author_avatar"
                                alt="avatar 1"
                            />
                        </div>
                        <div className="author_info_container">
                            <span className="author_name">
                               
                            </span>
                            <span className="author_date">
                                2022
                            </span>
                        </div>
                    </div>

                    <div >
                        <span className="card_tag_container">Data Essentials</span>
                    </div>
                </div>
            </div>

            <div className="card_container">
                <a href="#" className="card_image_container">
                    <img
                        src={a}
                        alt="card 1 image"
                        className="card_image"
                        loading="lazy"
                    />
                </a>

                <div className="card_title_container">
                    <a href="#" className="card_title_anchor">
                        <h2 className="card_title">AWS Fundamental</h2>
                    </a>
                    <p className="card_desc">
                        I had learn about AWS storage like EC2, cloud storage technique in a workshop conducted my AWS community mentors.
                    </p>
                </div>

                <div className="card_footer_container">

                    <div className="author_container">
                        <div className="author_avatar_container">
                            <img 
                                src="https://api.dicebear.com/7.x/notionists/svg?seed=John?size=64"
                                loading="lazy"
                                className="author_avatar"
                                alt="avatar 1"
                            />
                        </div>
                        <div className="author_info_container">
                            <span className="author_name">
                                
                            </span>
                            <span className="author_date">
                                2023
                            </span>
                        </div>
                    </div>

                    <div >
                        <span className="card_tag_container">AWS</span>
                    </div>
                </div>
            </div>

            <div className="card_container">
                <a href="#" className="card_image_container">
                    <img
                        src={am}
                        alt="card 1 image"
                        className="card_image"
                        loading="lazy"
                    />
                </a>

                <div className="card_title_container">
                    <a href="#" className="card_title_anchor">
                        <h2 className="card_title">Azure Fundamental Badge</h2>
                    </a>
                    <p className="card_desc">
                        I had also gain a knowledge of Azure Fundamental like NOsql , Big Data,SQL etc.
                    </p>
                </div>

                <div className="card_footer_container">

                    <div className="author_container">
                        <div className="author_avatar_container">
                            <img 
                                src="https://api.dicebear.com/7.x/notionists/svg?seed=John?size=64"
                                loading="lazy"
                                className="author_avatar"
                                alt="avatar 1"
                            />
                        </div>
                        <div className="author_info_container">
                            <span className="author_name">
                                
                            </span>
                            <span className="author_date">
                                2023
                            </span>
                        </div>
                    </div>

                    <div >
                        <span className="card_tag_container">Azure</span>
                    </div>
                </div>
            </div>

            <div className="card_container">
                <a href="#" className="card_image_container">
                    <img
                        src={u}
                        alt="card 1 image"
                        className="card_image"
                        loading="lazy"
                    />
                </a>

                <div className="card_title_container">
                    <a href="#" className="card_title_anchor">
                        <h2 className="card_title">Machine Learning Absolute Begineer</h2>
                    </a>
                    <p className="card_desc">
                       I had learn about Python and Machine Learning concept from udemy and make a real life projects.
                    </p>
                </div>

                <div className="card_footer_container">

                    <div className="author_container">
                        <div className="author_avatar_container">
                            <img
                                src="https://api.dicebear.com/7.x/notionists/svg?seed=John?size=64"
                                loading="lazy"
                                className="author_avatar"
                                alt="avatar 1"
                            />
                        </div>
                        <div className="author_info_container">
                            <span className="author_name">
                    
                            </span>
                            <span className="author_date">
                                 2021
                            </span>
                        </div>
                    </div>

                    <div >
                        <span className="card_tag_container">Programming</span>
                    </div>
                </div>
            </div>

            <div className="card_container">
                <a href="" className="card_image_container">
                    <img src={gfg}
                        alt="card 1 image"
                        className="card_image"
                        loading="lazy"
                    />
                </a>

                <div className="card_title_container">
                    <a href="www.google.com" className="card_title_anchor">
                        <h2 className="card_title">SQL Basic </h2>
                    </a>
                    <p className="card_desc">
                        I had gain a praticial working experience of using SQL.
                    </p>
                </div>

                <div className="card_footer_container">

                    <div className="author_container">
                        <div className="author_avatar_container">
                            <img 
                                src="https://api.dicebear.com/7.x/notionists/svg?seed=John?size=64"
                                loading="lazy"
                                className="author_avatar"
                                alt="avatar 1"
                            />
                        </div>
                        <div className="author_info_container">
                            <span className="author_name">
                              
                            </span>
                            <span className="author_date">
                                2023
                            </span>
                        </div>
                    </div>

                    <div >
                        <span className="card_tag_container">Database</span>
                    </div>
                </div>
                </div>
  
        </main>

    </div>
    
    <div id='cont'>
          <h1 className='contactpagetitle'>Contact Me</h1>
          <p className='contactdesc'>Connect to hire me</p>
          <form  className='contactform' ref={form} onSubmit={sendEmail}>
            <input type="text" className='name' placeholder='Your Name' name='your_name'></input>
            <input type="email" className='email' placeholder='Your Email' name='your_email'></input>
            <textarea name="message" className="msg" rows="10"  placeholder='Your Message' ></textarea>
            <button type="submit" value="send" className='btn'>submit</button>
             
             <div className='links'>
              <a href="https://www.linkedin.com/in/shivani-jaiswal-a154821b0/"><img src={Linkedin} alt="Github" className='link'/></a>
              <a href="https//github.com/shivani123-code" ><img src={Github} alt="Likedin" className='link'/></a>
              <a href="https://www.kaggle.com/shivijaiswal"><img src={Kaggle} alt="Kaggle" className='link'/></a>
              <a href="https://auth.geeksforgeeks.org/user/shigfg/?utm_source=geeksforgeeks&utm_medium=my_profile&utm_campaign=auth_user"><img src={g} alt="GFG" className='link'/></a>
              <a href="https://www.codingninjas.com/studio/profile/shivani123"><img src ={c} alt="Coding Ninja" className='link'/></a>
            </div>

          </form>
            
        </div>
    
</section>
  );
}

export default Training;
