import React from 'react';
import './work.css';
import html from '../../assests/html.jpg';
import jascpt from '../../assests/javasct.jpg';
import pyhton from '../../assests/python.jpg';
import c from '../../assests/c.jpg';
import ml from '../../assests/ml.jpg';
import rt from '../../assests/react.jpg';
import sql from '../../assests/sql.jpg';
import git from '../../assests/Github.jpg';


const Works = () => {
  return (
    <section id="works">
        <h2 className='worktitle'>
            Skills
        </h2>
        <span className='workdesc'>Technicial Skills, I have </span>
        <div className='workimgs'>
            <img src={html} alt ="pfp" className='workimg'/>
            <img src={sql} alt ="pfp" className='workimg'/>
            <img src={rt} alt ="pfp" className='workimg'/>
            <img src={ml} alt ="pfp" className='workimg'/>
            <img src={pyhton} alt ="pfp" className='workimg'/>
            <img src={c} alt ="pfp" className='workimg'/>
            <img src={jascpt} alt ="pfp" className='workimg'/>
            <img src={git} alt ="pfp" className='workimg'/>
            

        </div>
        <button className='workbtn'>See more</button>
        
    </section>
  )
  }

export default Works;
