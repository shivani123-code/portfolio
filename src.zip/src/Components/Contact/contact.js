import React from 'react';
import './contact.css';


const Contact = () => {
  return (
    <section id="contact">
        <div className='client'>
            <h1 className='contacttilte'>Work, I done</h1>
            <p className='cliendesc'>The works i have done during my academic 
            </p>
        </div>
        <div className='skillbars1'>
                    <div className='skillbar1'>
                        <div className='skillbartext1'>
                            <h2>Frontend-Works</h2><br></br>
                            <h3 className='skillbar3'>Portfolio Website </h3>
                            <p>A Personal portfolio website design using simple tool of React. It will have my  own, personal place, where i have hang my all technicila skills and my achievemnts.</p><br></br>
                            <button type='value' className='btnlink'>Github Link</button><br/><br/>

                            <h3 className='skillbar3'>E-Commerce Webiste</h3>
                            <p> Developed responsive layouts for diverse devices, enhancing user experience. Collaborated on product showcase, integrating smooth transitions and 
                              intuitive design. </p><br/>
                              <button type='value' className='btnlink'>Github Link</button><br/><br/>
                          <h3 className='skillbar3'>AMAZON CLONE</h3>
                          <p> By developing a web application with similar features such as product listings, user accounts, shopping cart, and secure payment processing, 
                            the project provided users with a familiar and seamless online shopping experience resembling that of Amazon.
                         </p><br></br>
                         <button type='value' className='btnlink'>Github Link</button><br/><br/>
                        </div>
                       </div>
                </div>
                <div className='skillbars1'>
                    <div className='skillbar1'>
                        <div className='skillbartext1'>
                          <h2>Deep Learning </h2><br/>
                          <h3 className='skillbar3'>A FACE MASK DETECTION</h3>
                            <p> In this project, a face mask detection system was developed using computer vision techniques. The goal was to accurately detect whether 
                                    individuals were wearing masks or not in real-time. 
                </p><br></br>
                <button type='value' className='btnlink'>Github Link</button><br/><br/>
                </div>
                </div>
                </div>
                <div className='skillbars1'>
                    <div className='skillbar1'>
                        <div className='skillbartext1'>
                          <h2>Machine Learning</h2><br/>
                          <h3 className='skillbar3'>STUDENT MARKS PREDICTION</h3>
                            <p> Developed a predictive model using linear regression to estimate students' marks based on their performance in previous assessments. Analyzed a 
                                   dataset of student marks and relevant features
                </p><br/>
                <button type='value' className='btnlink'>Github Link</button><br/><br/>
                <h3 className ='skillbar3'>MOVIE RECOMMENDATION SYSYTEM</h3>
                            <p> Design,Develop, and Deploy algorithms, enabling systems to learn from data, make predictions using Machine Learning algorithm.
                </p><br></br>
                <button type='value' className='btnlink'>Github Link</button><br/><br/>
                </div>
                </div>
                </div>
          
                <div className='skillbars1'>
                    <div className='skillbar1'>
                        <div className='skillbartext1'>
                            <h2>Python</h2><br/>
                            <h3 className ='skillbar3'>Contact Management System</h3>
                            <p> This project is based on python using tkiner module in which we edit, save, delete the details of employee as per our requirement. 
                                         The main aim of my project is to reduce the paper work and tree
                </p><br></br>
                <button type='value' className='btnlink'>Github Link</button><br/><br/>
                </div>
                </div>
                </div>

          
    </section>
  )
}

export default Contact;
