import React from 'react';
import './skill.css';
import spt from '../../assests/itnac.jpg'
import act from '../../assests/spt.jpg';
import a from '../../assests/internsh.jpg';
import b from '../../assests/cisco.png';
import c from '../../assests/micro.jpg';
import d from '../../assests/gt.jpg';
import e from '../../assests/it.jpg';


const Skill = () => {
    return (
        <section id="skill">
            <span className='skilltitle'>
                 What I do,</span>
                 <span className='skilldesc'>As a frontend engineer, I craft the user interface, ensuring a seamless and visually appealing experience and 
                  turning design concepts into interactive websites.On the backend, your focus shifts to server-side logic, databases, and APIs, weaving the infrastructure that powers the frontend magic.</span>
                 <div className='skillbars'>
                    <div className='skillbar'>

                        <div className='skillbartext'>
                            <h2>Training I have complete</h2><br/>
                            <img src ={a}alt="" className='skillbarimg'/>
                            <h3>Machine Learning Training</h3>
                            <p> The training encompassed a thorough exploration of data analysis techniques, involving statistical modeling, hypothesis testing,
 Machine Learning: Within the machine learning training program, I acquired extensive knowledge and practical expertise across various machine learning domains. This included the complete machine learning life cycle, covering foundational concepts like 
supervised and unsupervised learning.
                </p><br/>
                <img src ={d}alt="" className='skillbarimg'/>
                <h3>TRAINING IN KERAS from GREAT LEARNING</h3>
                            <p>he Tesnorflow and Keras training provided a comprehensive understanding of deep learning frameworks.
 I gained hands-on experience in building, training, and evaluating neural networks using Tesnorflow and leveraging the high-level API of Keras for 
efficient model development</p><br></br>
                             <img src ={e}alt="" className='skillbarimg'/>
                            <h3>WEB DEVELOPER AZEOTROPY IITBOMBAY</h3>
                            <p>Comprehensive Training: I received comprehensive training in three fundamental web development technologies: HTML, CSS, and JavaScript..
 Responsive and Interactive Web Pages: I developed proficiency in building web pages that are both responsive and interactive. This involved 
using HTML for structuring content, CSS for styling and layout, and JavaScript for adding dynamic functionality...</p><br></br>
                        </div>
                    </div>
                 </div>
                 <div className='skillbars'>
                    <div className='skillbar'>
            
                        <div className='skillbartext'>
                            <h2>Internships</h2><br></br>
                            <img src ={act} alt="" className='skillbarimg'/>
                            <h3>BUSINESS ANALYST FROM THE SPARK FOUNDATIOY</h3>
                                These internship help me to get valuable learning opportunities, allowing me to gain insights through these help me to get  
                                a deeper appreciation for the real-world applications of business analysis, especially in the context of leveraging advanced analytical techniques like machine learning<p></p><br></br>
                            <img src ={spt} alt="" className='skillbarimg'/>
                            <h3>MACHINE LEARNING INTERN FROM THE INTERN ACADEMY</h3>
                            <p>Diverse Real-Life task , During my internship as a Machine Learning engineer I actively participated in a wide range of practical tasks,
                               which significantly contributed to the expansion of my knowledge and skill set.</p>
                        </div>
                    </div>
                 </div>
                
        </section>

    );
}

export default Skill;