import Navbar from "./Components/Navbar/Navbar";
import Intro from "./Components/Intro/intro";
import Skill from "./Components/Skill/skill";
import Works from "./Components/Works/works";
import Contact from "./Components/Contact/contact";
import Footer from "./Components/Footer/footer";
import Training from "./Components/Training/t";

function App() {
  return (
    <div className="App">
      <Navbar></Navbar>
      <Intro></Intro>
      <Skill></Skill>
      <Works></Works>
      <Contact></Contact>
      <Training></Training>
      <Footer></Footer>
    </div>
  );
}

export default App;
